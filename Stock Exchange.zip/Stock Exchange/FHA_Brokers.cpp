#include<iostream>
#include<cstdlib>
#include<ctime>
#include<unistd.h>
using namespace std;
int deposit(double &balance){
	double a;
	cout<<" Enter the ammount to deposit"<<endl;
	cin>>a;
	if(a>0){
	balance=balance+a;
	system("CLS");
	cout<<" You Deposited : "<<a<<" "<<"Amount"<<endl<<endl;
}
else{
	system("CLS");
	cout<<" You entered invalid amount"<<endl<<endl;
}
	return balance;
}

int withdraw(double &balance){
	double a;
	cout<<" Enter the ammount to withdraw"<<endl;
	cin>>a;
	if(a<=balance && a>=0){
	balance=balance-a;
	system("CLS");
	cout<<" Withdraw sucessfull"<<endl<<endl;
}
else{
	system("CLS");
	cout<<" You do not have enough amount to withdraw"<<endl<<endl;
}
	return balance;
}

void apple(double &apple_worth){
	double apple_price,apple_purchased_price;
	apple_price=apple_worth/400;
	srand(time(0));
	apple_purchased_price=apple_price-12+rand()%25;
	apple_worth=apple_worth-apple_price;
	apple_worth=apple_worth+apple_purchased_price;
}
void tesla(double &tesla_worth){
	double tesla_price,tesla_purchased_price;
	tesla_price=tesla_worth/300;
	srand(time(0));
	tesla_purchased_price=tesla_price-1+rand()%15;
	tesla_worth=tesla_worth-tesla_price;
	tesla_worth=tesla_worth+tesla_purchased_price;
}
void nike(double &nike_worth){
	double nike_price,nike_purchased_price;
	nike_price=nike_worth/600;
	srand(time(0));
	nike_purchased_price=nike_price-1+rand()%15;
	nike_worth=nike_worth-nike_price;
	nike_worth=nike_worth+nike_purchased_price;
}
void boeing(double &boeing_worth){
	double boeing_price,boeing_purchased_price;
	boeing_price=boeing_worth/100;
	srand(time(0));
	boeing_purchased_price=boeing_price-60+rand()%140;
	boeing_worth=boeing_worth-boeing_price;
	boeing_worth=boeing_worth+boeing_purchased_price;
}
void starbucks(double &starbucks_worth){
	double starbucks_price,starbucks_purchased_price;
	starbucks_price=starbucks_worth/900;
	srand(time(0));
	starbucks_purchased_price=starbucks_price-5+rand()%15;
	starbucks_worth=starbucks_worth-starbucks_price;
	starbucks_worth=starbucks_worth+starbucks_purchased_price;
}
int main (){
	int choice,count=0;
	int quantity;
	double balance=0;
	double apple_worth=8960,apple_price,apple_shares=0;
	double tesla_worth=7532,tesla_price,tesla_shares=0;
	double nike_worth=5754,nike_price,nike_shares=0;
	double boeing_worth=13565,boeing_price,boeing_shares=0;
	double starbucks_worth=3456,starbucks_price,starbucks_shares=0;
	char a='r';
	while(choice!=6){
	apple_price=apple_worth/400;
	tesla_price=tesla_worth/300;
	nike_price=nike_worth/600;
	boeing_price=boeing_worth/100;
	starbucks_price=starbucks_worth/900;
	cout<<"--------------------------------------------------------------------------------------------------------------------"<<endl;
	cout<<" Welcome to FHA Brokers"<<endl;
	cout<<"--------------------------------------------------------------------------------------------------------------------"<<endl<<endl;
	cout<<"--------------------------------------------------------------------------------------------------------------------"<<endl;
	cout<<" Apple : "<<apple_price<<"     "<<"Tesla : "<<tesla_price<<"     "<<"Nike : "<<nike_price<<"     ";
	cout<<"Boeing : "<<boeing_price<<"     "<<"Starbucks : "<<starbucks_price<<"     "<<endl;
	cout<<"--------------------------------------------------------------------------------------------------------------------"<<endl;
	cout<<" Press 1 to Deposit"<<endl;	
	cout<<" Press 2 to Withdraw"<<endl;
	cout<<" Press 3 to Buy Stocks"<<endl;
	cout<<" Press 4 to Sell Stocks"<<endl;
	cout<<" Press 5 to Check Live Updates for 15 Seconds"<<endl;			
	cout<<" Press 6 to Quit"<<endl<<endl;	
	cout<<" Your Balance is : "<<balance<<endl;
	apple(apple_worth);
	tesla(tesla_worth);
	nike(nike_worth);
	boeing(boeing_worth);
	starbucks(starbucks_worth);
	cin>>choice;
	
	switch(choice){
		case 1:
			deposit(balance);
			break;
		case 2:
			balance=withdraw(balance);
			break;
		case 3:
			system("CLS");
			cout<<"   Company     Price"<<endl;
			cout<<"    Apple      "<<apple_price<<" "<<endl; 
			cout<<"    Tesla      "<<tesla_price<<" "<<endl;
			cout<<"    Nike       "<<nike_price<<" "<<endl; 
			cout<<"    Boeing     "<<boeing_price<<" "<<endl;
			cout<<"    Starbucks  "<<starbucks_price<<" "<<endl<<endl<<endl;
			cout<<" Your Balance is : "<<balance<<endl<<endl<<endl;
			cout<<" Press 1 to Buy Apple"<<endl<<endl<<" Press 2 to Buy Tesla"<<endl<<endl;
			cout<<" Press 3 to Buy Nike"<<endl<<endl<<" Press 4 to Buy Boeing"<<endl<<endl;
			cout<<" Press 5 to Buy Starbucks"<<endl<<endl;
			cin>>choice;
			if(choice>=1 && choice<=5){
				cout<<" Enter Quantity to Buy"<<endl;
				cin>>quantity;
				switch(choice){
				case 1:
					if(quantity<=400 && quantity>=0){	
					if(quantity*apple_price<=balance-1){
						apple_shares=apple_shares+quantity;
						balance=balance-(apple_price*quantity);
						balance=balance-1;
						system("CLS");
						cout<<" You Bought"<<" "<<quantity<<" "<<"Shares of Apple at the Price of : "<<apple_price<<endl;
					}
					else{
						system("CLS");
						cout<<" You dont have enough money"<<endl;
					}
				}
					else{
						system("CLS");
						cout<<" This amount of Shares are not available to Buy"<<endl;
					}
					break;			
				case 2:		
					if(quantity<=300 && quantity>=0){	
					if(quantity*tesla_price<=balance-1){
						tesla_shares=tesla_shares+quantity;
						balance=balance-(tesla_price*quantity);
						balance=balance-1;
						system("CLS");
						cout<<" You Bought"<<" "<<quantity<<" "<<"Shares of Tesla at the Price of : "<<tesla_price<<endl;
					}
					else{
						system("CLS");
						cout<<" You dont have enough money"<<endl;
					}
				}
					else{
						system("CLS");
						cout<<" This amount of Shares are not available to Buy"<<endl;
					}
					break;
				case 3:	
					if(quantity<=600 && quantity>=0){				
					if(quantity*nike_price<=balance-1){
						nike_shares=nike_shares+quantity;
						balance=balance-(nike_price*quantity);
						balance=balance-1;
						system("CLS");
						cout<<" You Bought"<<" "<<quantity<<" "<<"Shares of Nike at the Price of : "<<nike_price<<endl;
					}
					else{
						system("CLS");
						cout<<" You dont have enough money"<<endl;
					}
				}
					else{
						system("CLS");
						cout<<" This amount of Shares are not available to Buy"<<endl;
					}
					break;	
				case 4:				
					if(quantity<=100 && quantity>=0){
					if(quantity*boeing_price<=balance-1){
						boeing_shares=boeing_shares+quantity;
						balance=balance-(boeing_price*quantity);
						balance=balance-1;
						system("CLS");
						cout<<" You Bought"<<" "<<quantity<<" "<<"Shares of Boeing at the Price of : "<<boeing_price<<endl;
					}
					else{
						system("CLS");
						cout<<" You dont have enough money"<<endl;
					}
				}
					else{
						system("CLS");
						cout<<" This amount of Shares are not available to Buy"<<endl;
					}
					break;					
				case 5:	
					if(quantity<=900 && quantity>=0){		
					if(quantity*starbucks_price<=balance-1){
						starbucks_shares=starbucks_shares+quantity;
						balance=balance-(starbucks_price*quantity);
						balance=balance-1;
						system("CLS");
						cout<<" You Bought"<<" "<<quantity<<" "<<"Shares of Starbucks at the Price of : "<<starbucks_price<<endl;
					}
					else{
						system("CLS");
						cout<<" You dont have enough money"<<endl;
					}
				}
					else{
						system("CLS");
						cout<<" This amount of Shares are not available to Buy"<<endl;
					}
					break;	
				default:
					system("CLS");
					cout<<" Invalid choice"<<endl;
			}
			}
			else{
				system("CLS");
				cout<<" Invalid Choice"<<endl;
			}	
			break;
		
		case 4:
			system("CLS");
			cout<<"   Company     Price"<<endl;
			cout<<"    Apple      "<<apple_price<<" "<<endl; 
			cout<<"    Tesla      "<<tesla_price<<" "<<endl;
			cout<<"    Nike       "<<nike_price<<" "<<endl; 
			cout<<"    Boeing     "<<boeing_price<<" "<<endl;
			cout<<"    Starbucks  "<<starbucks_price<<" "<<endl<<endl<<endl;
			cout<<" Your Balance is : "<<balance<<endl<<endl<<endl;
			cout<<" You have "<<apple_shares<<" Apple shares "<<endl;
			cout<<" You have "<<tesla_shares<<" Tesla shares "<<endl;
			cout<<" You have "<<nike_shares<<" Nike shares "<<endl;
			cout<<" You have "<<boeing_shares<<" Boeing shares "<<endl;
			cout<<" You have "<<starbucks_shares<<" Starbucks shares "<<endl<<endl;
			cout<<" Press 1 to Sell Apple"<<endl<<endl<<" Press 2 to Sell Tesla"<<endl<<endl;
			cout<<" Press 3 to Sell Nike"<<endl<<endl<<" Press 4 to Sell Boeing"<<endl<<endl;
			cout<<" Press 5 to Sell Starbucks"<<endl;
			cin>>choice;
			if(choice>=1 && choice<=5){
				cout<<" Enter Quantity to Sell"<<endl;
				cin>>quantity;
				switch(choice){
				case 1:		
					if(apple_shares>0 && apple_shares>=quantity && quantity>=0){
						balance=balance+(apple_price*quantity);
						balance=balance-1;
						apple_shares=apple_shares-quantity;
						system("CLS");
						cout<<" You Sold"<<" "<<quantity<<" "<<"Shares of Apple at the Price of : "<<apple_price<<endl;
					}
					else{
						system("CLS");
						cout<<" You dont have enough shares to sell"<<endl;
					}
					break;				
				case 2:				
					if(tesla_shares>0 && tesla_shares>=quantity && quantity>=0){
						balance=balance+(tesla_price*quantity);
						balance=balance-1;
						tesla_shares=tesla_shares-quantity;
						system("CLS");
						cout<<" You Sold"<<" "<<quantity<<" "<<"Shares of Tesla at the Price of : "<<tesla_price<<endl;
					}
					else{
						system("CLS");
						cout<<" You dont have enough shares to sell"<<endl;
					}
					break;				
				case 3:		
						if(nike_shares>0 && nike_shares>=quantity && quantity>=0){
						balance=balance+(nike_price*quantity);
						balance=balance-1;
						nike_shares=nike_shares-quantity;
						system("CLS");
						cout<<" You Sold"<<" "<<quantity<<" "<<"Shares of Nike at the Price of : "<<nike_price<<endl;
					}
					else{
						system("CLS");
						cout<<" You dont have enough shares to sell"<<endl;
					}
					break;				
				case 4:		
						if(boeing_shares>0 && boeing_shares>=quantity && quantity>=0){
						balance=balance+(boeing_price*quantity);
						balance=balance-1;
						boeing_shares=boeing_shares-quantity;
						system("CLS");
						cout<<" You Sold"<<" "<<quantity<<" "<<"Shares of Boeing at the Price of : "<<boeing_price<<endl;
					}
					else{
						system("CLS");
						cout<<" You dont have enough shares to sell"<<endl;
					}
					break;									
				case 5:	
						if(starbucks_shares>0 && starbucks_shares>=quantity && quantity>=0){
						balance=balance+(starbucks_price*quantity);
						balance=balance-1;
						starbucks_shares=starbucks_shares-quantity;
						system("CLS");
						cout<<" You Sold"<<" "<<quantity<<" "<<"Shares of Starbucks at the Price of : "<<starbucks_price<<endl;
					}
					else{
						system("CLS");
						cout<<" You dont have enough shares to sell"<<endl;
					}
					break;					
				default:
					system("CLS");
					cout<<" Invalid choice"<<endl;

			}
			}
			else{
				system("CLS");
				cout<<" Invalid Choice"<<endl;
			}		
			break;
			case 5:
			while(a=='r'){
			apple_price=apple_worth/400;
			tesla_price=tesla_worth/300;
			nike_price=nike_worth/600;
			boeing_price=boeing_worth/100;
			starbucks_price=starbucks_worth/900;
			apple(apple_worth);
			tesla(tesla_worth);
			nike(nike_worth);
			boeing(boeing_worth);
			starbucks(starbucks_worth);
			if(count<=6){
			system("CLS");
			cout<<"   Company     Price"<<endl;
			cout<<"    Apple      "<<apple_price<<" "<<endl; 
			cout<<"    Tesla      "<<tesla_price<<" "<<endl;
			cout<<"    Nike       "<<nike_price<<" "<<endl; 
			cout<<"    Boeing     "<<boeing_price<<" "<<endl;
			cout<<"    Starbucks  "<<starbucks_price<<" "<<endl<<endl;
			cout<<" Your Balance is : "<<balance<<endl;
			count++;
			sleep(2);
		}
		else{
			cout<<" Press 'r' to refresh and any other key to get back to menu"<<endl;
			cin>>a;
			count=0;
			system("CLS");
		}
		}
			break;
			case 6:
				cout<<"Good Bye";
				break;
			default:
			system("CLS");
			cout<<" Invalid Choice"<<endl<<endl;	
	}
}
}
